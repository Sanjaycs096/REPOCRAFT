#!/usr/bin/env python3
"""Install RepoCraft skill files into an existing project.

Local source installation is supported in Phase 0. Remote bootstrap is intentionally
not enabled until the canonical public repository URL and release integrity process
are finalized.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

AGENT_PATHS = {
    "antigravity": Path(".agent/skills/repocraft"),
    "claude-code": Path(".claude/skills/repocraft"),
    "project": Path(".repocraft/skill"),
}

REQUIRED = [
    Path("SKILL.md"),
    Path("references/safety-and-git-baseline.md"),
    Path("references/quality-gates.md"),
    Path("references/repository-intelligence.md"),
    Path("references/maintenance-policy.md"),
    Path("references/documentation-policy.md"),
    Path("references/github-presentation-policy.md"),
    Path("references/security-testing-policy.md"),
    Path("references/repair-and-regression-policy.md"),
    Path("references/git-workflow-policy.md"),
    Path("references/agent-compatibility.md"),
    Path("references/release-and-portability-policy.md"),
    Path("scripts/repocraft_intel.py"),
    Path("scripts/repocraft_maintenance.py"),
    Path("scripts/repocraft_security.py"),
    Path("scripts/repocraft_repair.py"),
    Path("scripts/repocraft_git.py"),
    Path("scripts/repocraft_status.py"),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Install RepoCraft into an existing project.")
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent,
                        help="Local RepoCraft source directory (default: installer directory).")
    parser.add_argument("--agent", choices=sorted(AGENT_PATHS), default="antigravity")
    parser.add_argument("--target", type=Path, default=Path.cwd(),
                        help="Existing project root (default: current directory).")
    parser.add_argument("--force", action="store_true",
                        help="Replace an existing RepoCraft installation after backing it up.")
    args = parser.parse_args()

    source = args.source.resolve()
    target = args.target.resolve()
    skill_source = source / "skill"
    if not skill_source.is_dir():
        print(f"ERROR: skill source directory not found: {skill_source}", file=sys.stderr)
        return 2

    missing = [str(item) for item in REQUIRED if not (skill_source / item).is_file()]
    if missing:
        print("ERROR: required skill files are missing: " + ", ".join(missing), file=sys.stderr)
        return 2
    if not target.is_dir():
        print(f"ERROR: target project directory does not exist: {target}", file=sys.stderr)
        return 2

    destination = target / AGENT_PATHS[args.agent]
    if destination.exists():
        if not args.force:
            print(f"STOP: destination already exists: {destination}")
            print("Review it first. Re-run with --force only if you intentionally want a backup and replacement.")
            return 3
        backup = destination.with_name(destination.name + ".backup")
        suffix = 1
        while backup.exists():
            backup = destination.with_name(destination.name + f".backup-{suffix}")
            suffix += 1
        shutil.copytree(destination, backup)
        print(f"Existing installation backed up to: {backup}")

    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(skill_source, destination)

    manifest = {
        "name": "RepoCraft",
        "version": "1.0.0-rc1",
        "agent": args.agent,
        "installed_to": str(destination),
        "files": {
            str(p.relative_to(destination)): sha256(p)
            for p in sorted(destination.rglob("*")) if p.is_file()
        },
    }
    (destination / "INSTALL-MANIFEST.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )

    print("RepoCraft skill installed.")
    print(f"Project: {target}")
    print(f"Skill:   {destination}")
    print("No application source files or project dependencies were changed.")
    print("Next: open the project in your coding agent and invoke the RepoCraft skill.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
